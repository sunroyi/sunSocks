package com.github.monkeywie.proxyee.intercept;

public class HttpProxyInterceptInitializer {
  public void init(HttpProxyInterceptPipeline pipeline){}
}
