package com.github.monkeywie.proxyee.proxy;

public enum ProxyType {
  HTTP, SOCKS4, SOCKS5
}
